---
title: people
date: 2024-01-01
tags:
  - information
draft: true
color: "#595848"
---
---
下岡 未歩
Miho Shimooka

---

長尾 謙登
Kento Nagao

---
