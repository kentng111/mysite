---
title: test+5
date: 2026-01-25
tags:
  - architecture
draft: false
color: "#595848"
---
test

![](cover_test1.jpeg)

![img](testtest.jpeg))