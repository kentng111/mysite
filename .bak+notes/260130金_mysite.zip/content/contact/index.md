---
title: contact
tags:
  - contact
date: 2024-01-01
draft: false
color: "#D9CA43"
---
<form action="https://ssgform.com/s/8GZjIVpyN5AV" method="post">
  <p>
    <label for="name">Name</label><br>
    <input
      type="text"
      id="name"
      name="name"
      placeholder="Name"
      required
      style="width:100%; box-sizing:border-box;">
  </p>

  <p>
    <label for="email">Email</label><br>
    <input
      type="email"
      id="email"
      name="email"
      placeholder="example@gmail.com"
      required
      style="width:100%; box-sizing:border-box;">
  </p>

  <p>
    <label for="message">Message</label><br>
    <textarea
      id="message"
      name="message"
      rows="10"
      required
      style="width:100%; box-sizing:border-box;"></textarea>
  </p>

  <p>
    <button type="submit">Submit</button>
  </p>
</form>

