---
title: test+3
date: 2026-01-04
tags:
  - architecture
draft: false
color: "#CED943"
---
test

![](cover_test1.jpeg)

![img](testtest.jpeg))