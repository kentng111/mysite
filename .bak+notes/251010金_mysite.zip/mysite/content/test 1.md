---
title: test 1
date: 2025-09-01
tags:
  - architecture
  - research
---
hogehoge
test test test test test test
test test test test test test test test test 
test test test 
test test test test test test 

test test test test test test test test test 
test test test test test test test test test test test test test test test test test test 