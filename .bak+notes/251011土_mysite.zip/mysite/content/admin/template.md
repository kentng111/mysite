---
title: <% tp.file.folder().split("/").pop() %>
---
